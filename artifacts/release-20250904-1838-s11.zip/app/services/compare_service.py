from datetime import datetime
from collections import defaultdict
from typing import Dict, List, Any, Tuple
from app.services.cashflow_service import generate_cashflow
from app.services.case_service import detect_case
from app.utils.calculation_log import log_calc
from app.utils.date_serializer import normalize_cashflow_row, extract_year_from_date
import os


def _yearly_totals(rows: List[Dict[str, Any]]) -> Dict[str, Dict[str, float]]:
    """
    עוזר: הפקת (year -> totals) עבור רשימת שורות תזרים
    שדות לצבירה: inflow, outflow, additional_income_net, capital_return_net, net
    """
    acc: Dict[str, Dict[str, float]] = defaultdict(lambda: {
        "inflow": 0.0, 
        "outflow": 0.0, 
        "additional_income_net": 0.0, 
        "capital_return_net": 0.0, 
        "net": 0.0
    })
    
    for r in rows:
        # תאריך יכול להיות str "YYYY-MM-DD" או date — לאחד ל-YYYY
        y = extract_year_from_date(r["date"])
            
        acc[y]["inflow"] += float(r.get("inflow", 0) or 0)
        acc[y]["outflow"] += float(r.get("outflow", 0) or 0)
        acc[y]["additional_income_net"] += float(r.get("additional_income_net", 0) or 0)
        acc[y]["capital_return_net"] += float(r.get("capital_return_net", 0) or 0)
        acc[y]["net"] += float(r.get("net", 0) or 0)
    
    return {year: {k: round(v, 2) for k, v in totals.items()} for year, totals in acc.items()}


def compare_scenarios(
    db_session,
    client_id: int,
    scenario_ids: List[int],
    from_yyyymm: str,
    to_yyyymm: str,
    frequency: str = "monthly",
    case_id: int = None,
) -> Dict[str, Any]:
    """
    משווה מספר תרחישים עבור לקוח נתון ומחזיר תזרים חודשי וטוטלים שנתיים
    """
    # Auto-detect case if not provided
    if case_id is None:
        case_detection_result = detect_case(db_session, client_id)
        case_id = case_detection_result.case_id
        case_name = case_detection_result.case_name
        case_reasons = case_detection_result.reasons
    else:
        # Just get case name for logging
        try:
            case_detection_result = detect_case(db_session, client_id)
            case_name = case_detection_result.case_name
            case_reasons = case_detection_result.reasons
        except Exception:
            # If detection fails but case_id was provided, use defaults
            case_name = f"CASE_{case_id}"
            case_reasons = ["manually_provided"]
    
    # Log calculation start
    payload = {
        "client_id": client_id,
        "scenario_ids": scenario_ids,
        "from_yyyymm": from_yyyymm,
        "to_yyyymm": to_yyyymm,
        "frequency": frequency,
        "case_id": case_id,
        "case_name": case_name
    }
    
    debug_info = None
    if os.getenv("DEBUG_CALC", "0") == "1":
        debug_info = {
            "validation_checks": {
                "frequency_supported": frequency == "monthly",
                "scenario_count": len(scenario_ids)
            }
        }
    
    # ולידציה בסיסית (ספרינט 7 כבר בודק בפונקציות קיימות, כאן מחזקים)
    if frequency != "monthly":
        log_calc("compare_scenarios_error", payload, None, {"error": "Invalid frequency"})
        raise ValueError("Only 'monthly' is supported")

    # הפקת תזרים עבור כל תרחיש
    result: Dict[str, Any] = {
        "scenarios": {}, 
        "meta": {
            "client_id": client_id, 
            "from": from_yyyymm, 
            "to": to_yyyymm, 
            "frequency": frequency,
            "case": {
                "id": case_id,
                "name": case_name,
                "reasons": case_reasons
            }
        }
    }
    
    for sid in scenario_ids:
        # משתמש בפונקציה הקיימת מספרינט 7, עם העברת מזהה המקרה
        rows = generate_cashflow(db_session, client_id, sid, from_yyyymm, to_yyyymm, case_id=case_id)
        
        # נוודא שהשדה date יחזור כ-YYYY-MM-01 (מחרוזת) — אחידות
        norm_rows = [normalize_cashflow_row(r) for r in rows]
            
        result["scenarios"][str(sid)] = {
            "monthly": norm_rows,
            "yearly": _yearly_totals(norm_rows),
        }
    
    # Logical validation checks
    _validate_scenario_results(result)
    
    # Log successful completion
    log_calc("compare_scenarios", payload, result, debug_info)
    return result


def _validate_scenario_results(result: Dict[str, Any]):
    """
    Validate scenario comparison results for logical consistency
    Checks for negative taxes, extreme values, etc.
    """
    warnings = []
    
    for scenario_id, scenario_data in result.get("scenarios", {}).items():
        yearly_data = scenario_data.get("yearly", {})
        
        for year, totals in yearly_data.items():
            # Check for extremely negative net values (potential calculation error)
            net = totals.get("net", 0)
            if net < -1000000:  # Less than -1M NIS per year
                warnings.append(f"Scenario {scenario_id}, Year {year}: Extremely negative net cashflow ({net:,.0f})")
            
            # Check for unrealistic positive values
            inflow = totals.get("inflow", 0)
            if inflow > 50000000:  # More than 50M NIS per year
                warnings.append(f"Scenario {scenario_id}, Year {year}: Unrealistic inflow amount ({inflow:,.0f})")
            
            # Check for negative additional income (should be positive or zero)
            add_income = totals.get("additional_income_net", 0)
            if add_income < -100000:  # Less than -100K (some negative is OK for taxes)
                warnings.append(f"Scenario {scenario_id}, Year {year}: Suspicious additional income ({add_income:,.0f})")
    
    # Log warnings if any
    if warnings:
        log_calc("validation_warnings", {"scenario_count": len(result.get("scenarios", {}))}, warnings)
