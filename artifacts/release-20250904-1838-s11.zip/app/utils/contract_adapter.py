"""
Contract adapter layer to standardize function signatures and API responses
"""
from typing import Any, Dict, List, Optional
from sqlalchemy.orm import Session
from app.schemas.report import ReportPdfRequest


class ReportServiceAdapter:
    """Adapter for report service to maintain stable API contract"""
    
    @staticmethod
    def generate_pdf_report(
        db: Session,
        client_id: int,
        scenario_id: int,
        request: ReportPdfRequest
    ) -> bytes:
        """
        Standardized PDF generation interface
        
        Args:
            db: Database session
            client_id: Client ID
            scenario_id: Scenario ID  
            request: Report request with date range and sections
            
        Returns:
            PDF as bytes
        """
        from app.services.report_service import generate_report_pdf
        
        # Call the actual service with standardized parameters
        return generate_report_pdf(
            db=db,
            client_id=client_id,
            scenario_id=scenario_id,
            request=request
        )


class CompareServiceAdapter:
    """Adapter for compare service to ensure consistent response format"""
    
    @staticmethod
    def compare_scenarios_for_api(
        db_session: Session,
        client_id: int,
        scenario_ids: List[int],
        from_yyyymm: str,
        to_yyyymm: str,
        frequency: str = "monthly"
    ) -> Dict[str, Any]:
        """
        Standardized scenario comparison for API endpoints
        
        Returns:
            Consistent format with results array containing scenario data
        """
        from app.services.compare_service import compare_scenarios
        
        # Get raw data from service
        data = compare_scenarios(
            db_session=db_session,
            client_id=client_id,
            scenario_ids=scenario_ids,
            from_yyyymm=from_yyyymm,
            to_yyyymm=to_yyyymm,
            frequency=frequency
        )
        
        # Convert to standardized API format
        results = []
        for scenario_id, scenario_data in data.get("scenarios", {}).items():
            monthly_data = scenario_data.get("monthly", [])
            yearly_data = scenario_data.get("yearly", {})
            
            # Ensure yearly data exists even if empty
            if not yearly_data:
                yearly_data = {}
            
            results.append({
                "scenario_id": int(scenario_id),
                "monthly": monthly_data,
                "yearly": yearly_data
            })
        
        return {
            "results": results,
            "meta": data.get("meta", {})
        }


class CaseDetectionAdapter:
    """Adapter for case detection to ensure consistent response format"""
    
    @staticmethod
    def detect_case_for_api(db_session: Session, client_id: int) -> Dict[str, Any]:
        """
        Standardized case detection for API endpoints
        
        Returns:
            Simple case detection response
        """
        try:
            from app.services.case_service import detect_case
            result = detect_case(db_session, client_id)
            return {
                "case": result.case_name if hasattr(result, 'case_name') else "standard",
                "case_id": result.case_id if hasattr(result, 'case_id') else 1
            }
        except Exception:
            # Fallback to standard case
            return {
                "case": "standard",
                "case_id": 1
            }
