# Retirement Planning System - Installation Guide

## Quick Start with Docker

1. Extract the deployment package
2. Navigate to the project directory
3. Run the deployment script:
   ```bash
   chmod +x scripts/deploy.sh
   ./scripts/deploy.sh staging
   ```

## Manual Installation

### Prerequisites
- Python 3.11+
- PostgreSQL 12+
- Docker (optional)

### Steps
1. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Set up database:
   ```bash
   # Create database
   createdb retirement_db
   
   # Run migrations
   alembic upgrade head
   ```

3. Start the application:
   ```bash
   uvicorn app.main:app --host 0.0.0.0 --port 8000
   ```

## Configuration

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string
- `ENVIRONMENT`: production/staging/development
- `DEBUG`: Enable debug mode (development only)

### Database Setup
The system uses PostgreSQL with Alembic migrations. Run `alembic upgrade head` to create all required tables.

## API Documentation
Once running, visit:
- API Docs: http://localhost:8000/docs
- Health Check: http://localhost:8000/health

## Testing
Run the test suite:
```bash
pytest tests/ -v
```

## Support
For issues and support, refer to the documentation in the docs/ directory.
