"""
Client case detection service for workflow determination
"""
from datetime import date
from sqlalchemy.orm import Session
from typing import List, Optional

from app.models.client import Client
from app.models.current_employer import CurrentEmployer
from app.models.additional_income import AdditionalIncome
from app.schemas.case import ClientCase, CaseDetectionResult
from app.utils.calculation_log import log_calc

def detect_case(db: Session, client_id: int, *, retirement_age: int = 67) -> CaseDetectionResult:
    """
    Detect client case based on specified rules
    
    Rules:
    1. If client age >= retirement_age => Case 3 (PAST_RETIREMENT_AGE)
    2. If no current employer and has business income => Case 2 (SELF_EMPLOYED_ONLY)
    3. If no current employer and no business income => Case 1 (NO_CURRENT_EMPLOYER)
    4. If has current employer and no planned leave => Case 4 (ACTIVE_NO_LEAVE)
    5. If has current employer and planned leave => Case 5 (REGULAR_WITH_LEAVE)
    
    Args:
        db: Database session
        client_id: Client ID
        retirement_age: Retirement age threshold (default: 67)
        
    Returns:
        CaseDetectionResult with client_id, case_id, case_name, and reasons
    """
    # Get client data
    client = db.query(Client).filter(Client.id == client_id).first()
    if not client:
        raise ValueError(f"Client with ID {client_id} not found")
    
    # Check if client's birth date is available
    if not client.birth_date:
        raise ValueError(f"Client {client_id} has no birth date - cannot determine age")
    
    # Calculate current age
    today = date.today()
    age = today.year - client.birth_date.year - ((today.month, today.day) < (client.birth_date.month, client.birth_date.day))
    
    reasons: List[str] = []
    
    # Check if client is past retirement age (Case 3)
    if age >= retirement_age:
        case_id = 3
        case_name = ClientCase.PAST_RETIREMENT_AGE.value
        reasons.append(f"client_age_{age}_exceeds_retirement_age_{retirement_age}")
    else:
        # Check for current employer
        current_employer = db.query(CurrentEmployer).filter(CurrentEmployer.client_id == client_id).first()
        
        if not current_employer:
            # No current employer - check for business income (Case 2 vs Case 1)
            business_income = db.query(AdditionalIncome).filter(
                AdditionalIncome.client_id == client_id,
                AdditionalIncome.source_type == "business"
            ).first()
            
            if business_income:
                case_id = 2
                case_name = ClientCase.SELF_EMPLOYED_ONLY.value
                reasons.append("no_current_employer")
                reasons.append("has_business_income")
            else:
                case_id = 1
                case_name = ClientCase.NO_CURRENT_EMPLOYER.value
                reasons.append("no_current_employer")
                reasons.append("no_business_income")
        else:
            # Has current employer - check for planned leave (Case 4 vs Case 5)
            has_planned_leave = bool(
                current_employer.end_date or 
                client.planned_termination_date
            )
            
            if not has_planned_leave:
                case_id = 4
                case_name = ClientCase.ACTIVE_NO_LEAVE.value
                reasons.append("has_current_employer")
                reasons.append("no_planned_leave")
            else:
                case_id = 5
                case_name = ClientCase.REGULAR_WITH_LEAVE.value
                reasons.append("has_current_employer")
                if current_employer.end_date:
                    reasons.append(f"employer_end_date_set_{current_employer.end_date}")
                elif client.planned_termination_date:
                    reasons.append(f"planned_termination_date_set_{client.planned_termination_date}")
                else:
                    reasons.append("planned_leave_detected_or_default")
    
    # Create result
    result = CaseDetectionResult(
        client_id=client_id,
        case_id=case_id,
        case_name=case_name,
        reasons=reasons
    )
    
    # Log the case detection
    log_calc(
        event="case_detected",
        payload={"client_id": client_id, "retirement_age": retirement_age},
        result=result.dict(),
        debug_info={
            "client_age": age,
            "birth_date": str(client.birth_date),
        }
    )
    
    return result
