﻿"""
Schemas package initialization
"""

